import java.util.Scanner;
class SwappingDemo1
{
	public static void main(String args[])throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		System.out.println(a);
		System.out.println(b);
		a=a^b;
		b=a^b;
		a=a^b;
		System.out.println("after swapping");
		System.out.println(a);
		System.out.println(b);
	}

}