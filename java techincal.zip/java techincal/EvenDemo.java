import java.util.Scanner;
class EvenDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int number=sc.nextInt();
		if((number&1)==0)
			System.out.println("even");
		else
			System.out.println("odd");

	}
}