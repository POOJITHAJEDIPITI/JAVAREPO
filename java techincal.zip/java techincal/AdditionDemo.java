import java.util.Scanner;
class AdditionDemo
{
	public static void main(String args[])
	{
		Scanner obj=new Scanner(System.in);
		int a=obj.nextInt();
		int b=obj.nextInt();
		System.out.println(a+b);
	}
}