import java.io.*;
class ReadingDemo
{
	public static void main(String args[])throws Exception
	{
		Console c=System.console();//object creation 
		String s1=c.readLine("enter username");
		char[] s2=c.readPassword("enter your password");
		System.out.println(s1);
		System.out.println(s2);
}
}