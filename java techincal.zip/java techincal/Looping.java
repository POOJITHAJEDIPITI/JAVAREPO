class Looping
{
	public static void main(String args[])
	{
		for(int i=0;i<=5;i++)
		{
			System.out.println(i);
		}
		System.out.println(" ");
		for(int i=5;i>=0;i--)
		{
			System.out.println(i);
		}
		System.out.println(" ");
		//for(int i=1;i<=5;i--)
		//{
			//System.out.println(i);  infinite loop
		//}
		//for(int i=1;;i++)
		//{
		//	System.out.println(i);
		//}
		int i=0;
		for(;;)
		{
			System.out.println(i);
		}

	}
}