import java.util.Scanner;
import java.io.*;
class PresentNumber
{
	public static int main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		while(n<=0)
		{
		System.out.println(Integer.toString(n)).Contains(4);
	    }
	}

}