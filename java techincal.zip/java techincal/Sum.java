class Sum
{
public static void main(String args[])
{
int a=235;
int s=0,b=0,count=0;
while(a>0)
{

b=a%10;
count=count+1;
s=s+b;
if(count==2)
System.out.print(s);
a=a/10;
}
}
}