import java.util.Scanner;
class VowCon
{
	public  static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		char str2=0;
		char str3=0;
		for(int i=0;i<str.length();i++)
		{
		str2=str.charAt(i);
		
		System.out.println(str2);
		
		if(str2=='a'||str2=='e'||str2=='i'||str2=='o'||str2=='u')
		{
			str3=str2;
		
		System.out.println(str3);
		}
		}

		}
}