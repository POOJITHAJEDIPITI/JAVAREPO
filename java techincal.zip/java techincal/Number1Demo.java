import java.util.Scanner;
class Number1Demo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		String result=((a&1)==0)?"even":"odd";
		System.out.println(result);
		
	}
}