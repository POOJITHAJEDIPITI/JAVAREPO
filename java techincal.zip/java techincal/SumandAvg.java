import java.util.*;
import java.io.*;
class SumandAvg
{
	public static void main(String args[])throws Exception
	{
    Scanner sc=new Scanner(System.in);
	System.out.print("enter first value ->");
	int a=sc.nextInt();
	System.out.print("enter second value ->");
	int b=sc.nextInt();
	System.out.print("enter third value ->");
	int c=sc.nextInt();
	System.out.println("the sum of"+a +"and"+b +","+c +"is");
	System.out.println(a+b+c);
	int sum=a+b+c;
	float avg=sum/3;
	System.out.println("the average of"+a +"and"+b +","+c +"is");
	System.out.printf("%.2f\n",avg);
	}
	

}