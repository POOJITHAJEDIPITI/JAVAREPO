class WhileDemo23
{
	public static void main(String args[])
	{
		//while(true)
		//{
		//	System.out.println("aaa");
		//}
		//System.out.println("bbb");
		while(false)
		{
			System.out.println("aaa");
		}
		System.out.println("bbb");
	}
}