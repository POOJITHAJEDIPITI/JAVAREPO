import java.util.Scanner;
class RangeDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		if(num>=1 && num<=10)
			System.out.println("inclusive");
		else
			System.out.println("not in range");
	}
}