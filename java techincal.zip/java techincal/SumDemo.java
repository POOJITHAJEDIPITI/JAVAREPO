import java.io.*;
class SumDemo
{
	public static void main(String args[])throws Exception
	{
		Console c=System.console();
		int a=c.read("enter a value \n");
		int b=c.read("enter b value \n");
		System.out.println(a);
		System.out.println(b);
		System.out.println(a+b);
		
	}
}