class Demo
{
public static void main(String args[])
{
System.out.print("hello world\n");
System.out.println("hello world");
System.out.printf("%s","hello world");
}
}