import java.util.Scanner;
class NumberDemo1
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int i=0;
		while(i<=n)
		{
		 
		System.out.println(i);
		i++;
		}
	}
}