class StringConcating
{
	public static void main(String args[])
	{
		String a="hello";
		int c=10,b=20;
		System.out.println(a+c+b);
		System.out.println(b+c+a);
		System.out.println(a+" "+(b+c));
	}
}