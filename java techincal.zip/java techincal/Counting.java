import java.util.Scanner;
class Counting
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int arr[]=new int[size];
		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("array elements are");
		for(int j=0;j<arr.length;j++)
		{
			System.out.println(arr[j]);
		}
		System.out.println("the number of even and odd numbers in array is");
		for(int k=0;k<arr.length;k++)
		{
			int count=0;
			int even=0;
			if(arr[k]%2==0)
			{
				 even=count+1;
			}
			System.out.print(even);
			
		}
}
}