import java.io.*;
class Reading
{
	public static void main(String args[])throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter a character");
		int i=br.read();
		System.out.println(i);
		System.out.println("the character after type casting");
		System.out.println((char)i);
	}
}