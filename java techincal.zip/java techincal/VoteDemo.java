import java.util.Scanner;
class VoteDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int age=sc.nextInt();
		//if(age>=18)
		//{
		//	System.out.println("eligible");
		//}
		//else
		//{
		//	System.out.println("not eligible");
		//}
		String result=(age>=18)? "eligible":"not eligible";
		System.out.println(result);
	}
}