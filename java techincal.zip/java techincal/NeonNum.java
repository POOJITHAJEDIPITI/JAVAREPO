class NeonNum

{
	public static void main(String arg[])
	{
		int n=9;
		int a=n*n;
		int sum=0;
		do
		{
			int d=a%10;
			sum=sum+d;
			a=a/10;

		}
		while(a>0);
		if(sum==n)
			System.out.println("neon");
		else
			System.out.println("not neon");
	}
}