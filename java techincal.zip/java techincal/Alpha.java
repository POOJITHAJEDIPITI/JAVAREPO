import java.util.Scanner;
class  Alpha
{
	public static void main(String args[])
	{
		char ch;
		for(ch='A';ch<='z';ch++)
		{
			System.out.println(ch);
		}
	}
}