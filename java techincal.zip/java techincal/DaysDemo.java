import java.util.Scanner;
class DaysDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int days=sc.nextInt();
		System.out.println(days/7+" "+days%7);
		System.out.println(days/30+" "+days%30);
		System.out.println(days/365+" "+days%365);
	}
}