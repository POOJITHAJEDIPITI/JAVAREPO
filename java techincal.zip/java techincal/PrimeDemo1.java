import java.util.Scanner;
class PrimeDemo1
{
	public static void main(String args[])throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int prime=0;
		int num=sc.nextInt();
		for(int i=1;i<=num;i++)
		{
			if((num%i)==0)
			{
				prime=prime+1;
			}
		}
		if(prime==2)
		{
			System.out.println("prime");
		}
		else
		{
			System.out.println("not prime");
		}
	}
}