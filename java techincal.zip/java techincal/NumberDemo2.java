import java.util.Scanner;
class NumberDemo2
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		String result=(a>0)?"positive":(a<0)?"negative":"zero";
		System.out.println(result);
	}
}