import java.util.Scanner;
class Demo1
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		if(a>=1 && a<=100)
		{
			if(a>=18)
				System.out.println("ELIGIBLE");
			else
				System.out.println("NOT ELIGIBLE");
		}
		else
			System.out.println("you are dead");
}}