import java.util.*;
class Characters
{
public static void main(String args[])
{
System.out.printf("%C\n",'p');
System.out.printf("%C\n",'o');
System.out.printf("%C\n",'o');
System.out.printf("%C\n",'j');
System.out.printf("%C\n",'i');
System.out.printf("%C\n",'t');
System.out.printf("%C\n",'h');
System.out.printf("%C\n",'a');

}
}