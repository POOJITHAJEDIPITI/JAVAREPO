import java.util.Scanner;
class SwitchDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		final int x=10;
		switch(n)
		{
			case 0:System.out.println("ZERO");
			case 1:System.out.println("ONE");break;
			case 2:System.out.println("TWO");break;
			default:System.out.println("Invalid");break;

			case 3:System.out.println("THREE");break;
			case 8-1:System.out.println("SEVEN");break;
            case x:System.out.println("SEVEN");break;
			//case 2:System.out.println("TWO");break;
			case 4:System.out.println("FOUR");break;
			case 5:System.out.println("FIVE");break;
            case 6:System.out.println("SIX");
			

		}
	}


}
