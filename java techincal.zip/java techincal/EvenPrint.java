import java.util.Scanner;
class EvenPrint
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int i=0;
		while(i<=n)
		{
			System.out.println(i);
			i=i+2;
		}
	}
}