import java.util.Scanner;
class CircleDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		float r=sc.nextFloat();
		float area=22/7*r*r;
		System.out.printf("%.2f",area);
	}
}