import java.util.Scanner;
class Season
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		char ch=sc.next().charAt(0);
		switch(ch)
		{
			case 'j':System.out.println("January"+" "+"June"+" "+"July");break;
			case 'f':System.out.println("February");break;
			case 'M':System.out.println("May"+" "+"March");break;
			default:System.out.println("refer any dictionary to find all");
}
	}
}