class ValuesDemo
{
public static void main(String args[])
{
int a=10;
System.out.printf("%d\n",a);
System.out.printf("%o\n",a);
System.out.printf("%x\n",a);
System.out.printf("%X\n",a);
}
}
