class LinearSearching
{
	public static void main(String args[])
	{
		int arr[]={10,20,30,49,79};
		int key=709;
		int flag=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==key)
			{
				System.out.println("found");
			}
			
		}
		if(flag==1)
		{
			System.out.println("found");
		}
		else
		{
			System.out.println("not found");
		}
	}
}