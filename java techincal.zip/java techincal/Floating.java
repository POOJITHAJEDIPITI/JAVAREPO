class Floating
{
public static void main(String args[])
{
System.out.printf("%f\n",3.147);
System.out.printf("%.1f\n",3.147);
System.out.printf("%.2f\n",3.147);
System.out.printf("%.3f\n",3.147);
}
}