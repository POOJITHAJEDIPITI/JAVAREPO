class Palindrome
{
	public static void main(String args[])
	{
		int number=121;
		int temp=number;
		int rem;
		int sum=0;
		while(number>0)
		{
			rem=number%10;
			sum=(sum*10)+rem;
			number=number/10;
		}
		if(sum==temp)
		{
			System.out.println("palindrome");
		}
		else
		{
			System.out.println("not palindrome");
		}
	}
			
}