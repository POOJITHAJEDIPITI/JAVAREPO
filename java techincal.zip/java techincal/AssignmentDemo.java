class AssignmentDemo
{
	public static void main(String args[])
	{
		int a=10;//simple assignment
		System.out.println(a);
		int w,x,y,z;
		w=x=y=z=999;
		System.out.println(w);
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		System.out.println(w+x+y+z);
		System.out.println(w+" "+x+" "+y+" "+z);
		byte b=10;
		//b+=3;
		//b=b+3;
		b=(byte)(b+3);

		System.out.println(b);
	}
}