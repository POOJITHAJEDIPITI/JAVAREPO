class Conversion
{
public static void main(String args[])
{
String s="hema";
System.out.printf("%S",s);
}
}