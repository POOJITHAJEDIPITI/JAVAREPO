class WhileDemo11
{
	public static void main(String args[])
	{
		int a=1,b=2;
		while(a<b)
		{
			System.out.println("yes");
			a++;
	}
	System.out.println("NO");
	}
}