import java.util.Scanner;
class FrequencyCheck
{
	public static void main(String args[])throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int arr[]={1,1,3,4,2,4,5,6,6,6,5};
		int counter=0;
		for(int i=0;i<arr.length;i++)
		{
			counter=counter+1;
		}
		System.out.println(counter);
	}
}