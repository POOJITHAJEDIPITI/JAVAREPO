import java.util.Scanner;
class StrongDemo
{
	public static int fact(int n)
	{
		int fact=1;
		for(int i=1;i<=n;i++)
		{
			 fact=fact*i;
		}
		System.out.println(fact);
		return fact;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int temp=num;
		int sum=0;
		int rem=0;
		for(int i=0;i<=num;i++)
		{
			rem=num%10;
			sum=rem+fact(num);
			num=num/10;
		}
		if(sum==temp)
		{
			System.out.println("Strong number");
		}
		else
		{
			System.out.println("Not strong number");
		}
	}

}

			




