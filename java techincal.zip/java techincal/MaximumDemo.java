import java.util.Scanner;
class MaximumDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		int result=(a>b && a>c)?a:((b>a && b>c)?b:c);
		System.out.println(result);
		System.out.println("minimum");
		int result1=(a<b && a<c)?a:((b<a && b<c)?b:c);
		System.out.println(result1);
	}
}