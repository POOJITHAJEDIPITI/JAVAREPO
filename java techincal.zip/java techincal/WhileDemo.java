class WhileDemo
{
	public static void main(String args[])
	{
		int a=10,b=20;
		while(a<=b)
		{
			System.out.println(a++);
		}
	}
}