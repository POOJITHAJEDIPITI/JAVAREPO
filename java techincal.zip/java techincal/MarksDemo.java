import java.util.Scanner;
class MarksDemo
{
	public static void main(String args[])
	{
		Scanner  sc=new Scanner(System.in);
		int sub1=sc.nextInt();
		int sub2=sc.nextInt();
		int sub3=sc.nextInt();
		int sub4=sc.nextInt();
		int sub5=sc.nextInt();
        float total=(sub1+sub2+sub3+sub4+sub5);
		System.out.println(total);
		float percent=(total/500)*100;
		System.out.println(percent);
		if(sub1>=40 &&sub2>=40&&sub3>=40&&sub4>=40&&sub5>=40)
		{
			
				if(percent>=1 && percent<=100)
				{
			if(percent>=80)
					
				System.out.println("A");
			else if(percent<=80 && percent>=70)
				System.out.println("B");
			else if(percent<=70 && percent>=60)
				System.out.println("c");
			else
				System.out.println("Fail");
					
				}
				else
					System.out.println("enter valid marks");
		}
	
		else
		System.out.println("fail");
	}

}