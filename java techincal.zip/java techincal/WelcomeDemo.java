import java.util.*;
class WelcomeDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your name");
		String name=sc.nextLine();
		System.out.println("welcome to mother theresa institute of computer applications"+" "+name);
	}
}