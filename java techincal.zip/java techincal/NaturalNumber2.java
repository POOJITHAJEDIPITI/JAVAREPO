import java.util.Scanner;
class NaturalNumber2
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=n;n>=1;n--)
		{
			System.out.println(n);
		}
	}

}